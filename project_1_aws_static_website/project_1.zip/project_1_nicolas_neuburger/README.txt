# Project 1 - Submission: Nicolas Neuburger

Hey reviewers, 
the static website is up and running, so here is the CloudFront endpoint:

dv3lti75bnn09.cloudfront.net

The instructions have been exactly up to date, so a big compliment on that, because the frontend of amazon is changing a lot, I guess... 

## Update Suggestion
I had to set "index.html" as the root object for my cloudfront instance, so that my browser immediately recieves it on request. This could be added to the instructions in the next version (or I overlooked that).
