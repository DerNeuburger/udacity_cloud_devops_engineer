# Project 2 - Deploy high availble Web App using Cloud Formation

Hello reviewers,

Udagram is hosted on the following URL:

http://proje-webap-lmbp7s3souxp-1003138780.eu-central-1.elb.amazonaws.com/

It was created using the four configurations and parameter files. The sepeartion into multiple files was done to have a better overview and maybe at one point reuse parts of the configurations in other projects. In order to recreate the cloud architecture using the given files the following prerequisites must be met.

## Prerequisites

1.) Run the aws client with user credentials, that allow to automatically create IAM role and instance profiles.
2.) Create or provide two valid key pairs.
3.) Configure the parameter files to your needs (My IP Address, Names of Key Pairs, ...)

## Deployment

The ```manage_stack.sh``` provides a shell script that facilitates a wrapper around the aws_cli command to save some time when starting up the stacks. In order to create the configurations run the following lines in order. Make sure after every command that the stack is correctly created by using the management console or aws_cli.

```
./manage_stack.sh project-2-network cfn_network.yml parameters_network.json
./manage_stack.sh -c project-2-permissions cfn_permissions.yml parameters_permissions.json
./manage_stack.sh project-2-webservers cfn_webservers.yml parameters_webservers.json
./manage_stack.sh project-2-bastion-hosts cfn_bastion_hosts.yml parameters_bastion_hosts.json
```
